package com.dam.alberto;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);

		int num1;
		int num2;
		int primo;
		
		System.out.println("Dime un numero");
		num1= teclado.nextInt();
		
		System.out.println("Dime otro numero");
		num2=teclado.nextInt();
		
		
		if( num1<0 || num2<0) {
			System.out.println("Los numeros deben ser positivos");
		}else if(num2>num1) {
			for(int i = num1; i<=num2; i++) {
				if(i==1) {
					System.out.println(i);
				}else {
					primo = i%2;
					
					if(i==2) {
						
						System.out.println(i + " es numero primo");
						
					}else if(primo==0){
						
						System.out.println(i);	
						
					}else {
						primo=i%3;
						
						if(i==3) {
							System.out.println(i + " es numero primo");
						}else if(primo==0){
							System.out.println(i);
						}else {
							System.out.println(i + " es numero primo");
						}
					}
				}
				
				
			}
		}else if(num1>num2){
			for(int i = num2; i<=num1; i++) {
				if(i==1) {
					System.out.println(i);
				}else {
					primo = i%2;
					
					if(i==2) {
						
						System.out.println(i + " es numero primo");
						
					}else if(primo==0){
						
						System.out.println(i);	
						
					}else {
						primo=i%3;
						
						if(i==3) {
							System.out.println(i + " es numero primo");
						}else if(primo==0){
							System.out.println(i);
						}else {
							System.out.println(i + " es numero primo");
						}
					}
				}
				
				
			}
		}else if( num1==num2) {
			
			System.out.println("Los numeros son iguales");
		}
		
		
		
	}

}
