package com.dam.alberto;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int acabar=0;
		int num;
		int numero;
		ArrayList<String> listaComp = listaCompanyeros();
		
		ArrayList<Integer> numeros = new ArrayList<Integer>();
		
		do {
			
			System.out.println("Dime un numero");
			num= teclado.nextInt();
			
			numeros.add(num);
			
			System.out.println("Quieres poner otro numero? Si=0   No=1");
			acabar=teclado.nextInt();
			
		}while(acabar==0);
		
		for(int i=0; i< numeros.size(); i++) {
			
			
			
		}
		
		
		
	}

	public static ArrayList<String> listaCompanyeros(){
		
		ArrayList<String> lista = new ArrayList<String>(5);
		lista.add("Alberto");
		lista.add("Quique");
		lista.add("Carles");
		lista.add("Pablo");
		lista.add("Gonzalo");
		lista.add("Daniela");
		
		return lista;
		
	}
	
}
